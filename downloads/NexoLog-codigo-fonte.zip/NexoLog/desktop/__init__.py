"""Distribuição Windows do NexoLog."""
