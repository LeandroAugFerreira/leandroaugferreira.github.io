# Vídeo de apresentação

O vídeo apresenta as telas do NexoLog, com narração em português brasileiro e legendas selecionáveis em Português BR e English. O player do portfólio também permite desativar as legendas.

O roteiro está em `docs/roteiro-video.json`. As capturas usam somente a demonstração fictícia. A cena de rastreamento apresenta uma simulação, sem GPS real.

O MP4 é montado em Full HD (1920 × 1080), com pixels quadrados e enquadramento que preserva a proporção original das telas. Antes de salvar cada captura, aguarde os indicadores e gráficos carregarem; os KPIs devem mostrar valores, sem reticências de carregamento. Para manter a nitidez, capture as telas em 1920 × 1080.

## Reproduzir a montagem

Requisitos adicionais para gerar o vídeo: FFmpeg instalado e a biblioteca `edge-tts`. Eles são necessários apenas para a montagem da apresentação; o executável do NexoLog funciona sem essas ferramentas.

```powershell
.\.venv\Scripts\python.exe -m pip install edge-tts
.\.venv\Scripts\python.exe scripts\narrar_video_natural.py
.\.venv\Scripts\python.exe scripts\montar_video.py
```

A geração da narração usa uma conexão com o serviço de voz da Microsoft e envia somente o texto público do roteiro. A reprodução do MP4 utiliza o áudio já incluído no arquivo.

Os resultados ficam em `releases/video/`:

- `nexolog-apresentacao.mp4`: vídeo, áudio em português e duas faixas de legenda.
- `nexolog-pt.vtt` e `nexolog-en.vtt`: legendas usadas pelo player do site.
- `capitulos.json`: intervalos dos capítulos.

O montador calcula os tempos a partir dos áudios de cada frase e regenera as legendas, mantendo a sincronização após mudanças na narração. Quando não existem capturas em `build/video-frames/`, ele utiliza as imagens de `docs/imagens/`.
