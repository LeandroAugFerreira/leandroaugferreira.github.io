"""API e regras operacionais do NexoLog."""
