# NexoLog

**Sua operação conectada.**

Sistema de gestão logística que integra estoque, pedidos, fornecedores, clientes, entregas e indicadores em uma única operação. Interface em português brasileiro, com tema escuro, visualização para desktop e adaptação para dispositivos móveis.

![Dashboard do NexoLog](docs/imagens/dashboard-ajustado.png)

## Funcionalidades

- Dashboard com indicadores, fluxo de estoque, pedidos recentes e alertas.
- Produtos com categoria, marca, especificação/variante e código de barras, além de precificação e controle de saldo.
- Pedidos em Kanban, filtro livre por período, reserva de estoque, expedição, entrega, cancelamento e devolução.
- Cadastros de clientes, fornecedores e usuários, com perfis de acesso.
- Rastreamento demonstrativo com mapa esquemático, caminhão animado e histórico persistido.
- Relatórios por período, exportações CSV e trilha de auditoria integrada.

O rastreamento é uma **simulação de transporte**, sem conexão com GPS ou transportadoras reais. A API atualiza os eventos de entrega, movimentações de estoque, relatórios e auditoria enquanto o sistema está em execução.

## Experimentar no Windows

Baixe `NexoLog.exe` no cartão do projeto no [portfólio](https://leandroaugferreira.github.io/nexolog.html). Abra o arquivo e aguarde o navegador. Na tela de login, clique em **Usar acesso demo**.

Não é necessário instalar Python ou Node para usar o executável. A janela do NexoLog mantém o serviço local em execução; ao fechá-la, o serviço é encerrado. O navegador pode permanecer aberto, mas não recebe atualizações depois do encerramento.

A demonstração usa dados fictícios: 144 produtos, 24 fornecedores, 48 clientes, 10 usuários e 408 pedidos no período de 2024 a 2026. As alterações são salvas em `%LOCALAPPDATA%\NexoLog\nexolog-demo.db`, fora do executável. Atualizar o programa não substitui esse banco.

**Acesso da demonstração:** `demo@nexolog.app` / `NexoLog@2026`. Essas credenciais são públicas e exclusivas da base fictícia distribuída.

## Executar o código-fonte

Requisitos: Python 3.13 e Node.js compatível com Vite 8.

No primeiro terminal PowerShell, a partir da pasta do projeto:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
.\.venv\Scripts\python.exe -m scripts.iniciar_demo
```

No segundo terminal:

```powershell
cd frontend
npm.cmd ci
npm.cmd run dev
```

Acesse [http://localhost:5173](http://localhost:5173). A API fica em [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs). Em execuções seguintes, basta iniciar `scripts.iniciar_demo` e `npm.cmd run dev`.

## Tecnologias e arquitetura

| Camada | Tecnologias |
|---|---|
| Interface | React, Vite, React Router, Recharts |
| API | Python, FastAPI, Pydantic |
| Persistência | SQLite, SQLAlchemy |
| Distribuição Windows | PyInstaller, janela nativa do Windows |

O frontend consome a API autenticada. As operações de pedidos e estoque são realizadas em transações, com registros de auditoria. O serviço de simulação compartilha essas regras e registra o resultado das entregas no banco.

## Compilar o executável

Em um computador Windows com Python e Node instalados:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\build_windows.ps1
```

O resultado fica em `releases\NexoLog.exe`. Para gerar uma distribuição em pasta, use `-Folder`. O build inclui somente o frontend compilado e a base fictícia de `data/`; bancos locais, sessões do usuário, backups e arquivos `.env` ficam de fora.

## Validação

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Os testes usam bancos temporários e verificam autenticação, permissões, reservas, expedição, cancelamento, devolução, migrações e relatórios. O executável também oferece `--self-test --data-dir CAMINHO` para validar sua distribuição em um banco separado.

## Publicar no GitHub

Suba o código-fonte com seu README, imagens e base fictícia. Publique o executável na área **Releases**, como download da versão, e vincule a página de apresentação do portfólio ao download. O GitHub Pages hospeda a apresentação estática; a API Python e o SQLite rodam localmente pelo executável.

O arquivo `.gitignore` exclui dependências, ambientes Python, bancos operacionais e artefatos de compilação.
