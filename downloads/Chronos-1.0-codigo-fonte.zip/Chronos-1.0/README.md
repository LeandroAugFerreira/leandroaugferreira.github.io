# Chronos 1.0

**Chronos — Gestão Inteligente de Jornadas e Escalas.** Plataforma corporativa modular de planejamento, simulação e governança de jornadas. Hospital Horizonte é o cliente fictício de demonstração: 350 colaboradores, 19 setores e operação 24 horas. O núcleo utiliza setores, cargos, competências e jornadas configuráveis para outros segmentos.

**Checkpoint atual: Fase 10 — demonstração para Windows e documentação.** O projeto possui interface com identidade própria, iniciador desktop, manual HTML e pacote fonte para revisão. **Não há liberação de produção:** n8n bloqueado, QA de navegador/capturas, Power BI Desktop e itens funcionais/operacionais pendentes. A apresentação e os downloads no portfólio são distintos de uma implantação operacional.

## Experimente o aplicativo

O portfólio em https://leandroaugferreira.github.io/chronos.html reúne a demonstração para Windows e o manual online. O executável inclui os recursos necessários para uso local, sem exigir Python ou Node.js no computador do visitante. Mantenha sua janela aberta durante a utilização. Use organização `horizonte`, usuário `demo` e senha demonstrativa `ChronosDemo@2026` para consulta. Para testar os demais módulos, crie seu próprio administrador local pela janela de controle.

Consulte [o guia de uso](docs/portfolio/manual-web.md) e [as instruções do executável](desktop/README.md). Os dados da demonstração são criados fora do projeto; bancos, contas e credenciais do autor não são distribuídos.

## Entrega disponível

- FastAPI/Pydantic com autenticação JWT, refresh rotacionado, logout e revogação imediata; senhas Argon2id e limite persistente de login.
- SQLAlchemy/PostgreSQL e SQLite local opt-in; dez migrations Alembic, 41 tabelas e FKs compostas para isolamento entre organizações.
- Seis perfis com permissões efetivas no backend e escopo por unidade; salários separados da consulta de colaboradores.
- Endpoints de estrutura, catálogos, pessoas, contratos, competências, qualificações, disponibilidade, usuários e auditoria. Paginação, filtros, ordenação, revisão otimista e idempotência de criação.
- Seed transacional reproduzível do Hospital Horizonte e restauração restrita à demonstração.
- Frontend React/TypeScript/Tailwind: login, dashboard do banco com gráficos, gestão de colaboradores/unidades/setores/catálogos, criação de acessos e auditoria. Filtros/paginação, RHF/Zod, revisão de edição, dark/light e estados de rede.
- Sessão web com refresh em cookie HttpOnly/SameSite Strict, CSRF assinado ligado à família e access token somente em memória. Logout confirma revogação no servidor; nenhum token é guardado no localStorage.
- Calendário semanal/mensal com plantões/pausas, indisponibilidades, prévia obrigatória, rascunhos, revisão e histórico de avaliações. Jornadas configuráveis; regras tipadas com escopo/vigência, fontes e sucessão explícita de versões.
- Cenários imutáveis com snapshots, simulação por calendário/ciclo, demanda por atividade e comparativos. Capacidade agregada não comprova cobertura.
- Projeção financeira de 12 meses em centavos/Decimal: salários preservados, parcelas únicas/mensais/sazonais, taxas/divisores explícitos, contratações, comparativos e sensibilidade; acesso financeiro separado.
- Planejamento completo, Prompt Mestre consolidado, modelo, especificações de LaborRules/OR-Tools/financeiro/n8n, cronograma e critérios de aceite.

- Otimização em worker local com lease/heartbeat, cancelamento e recuperação; cobertura por intervalo com pausas, descanso, competências, ciclos e indisponibilidade. Objetivos separados das restrições; limites explícitos sem padrões jurídicos.
- Propostas imutáveis, nova versão por recálculo, submissão/aprovação/rejeição com digest, justificativa e trilha; alterações de insumos exigem recálculo e o autor não aprova a própria proposta.

- Central de automações com definições desativadas por padrão, responsável e agenda, fila/lease/retentativas, alertas deduplicados, indicadores CSV e sugestões que preservam a proposta existente.
- Quatro workflows n8n exportáveis e autenticados, testados em loopback com confirmação de execução e proteção contra replay. O núcleo funciona sem n8n; o adaptador local não envia a destinos remotos.

**Analytics completos, XLSX/Power BI e IA explicativa opcional continuam na Fase 8.** Os contratos/qualificações importados estão pendentes de revisão; integridade de cadastro não é validação trabalhista. A aprovação de propostas é interna e não publica escalas. Detalhes em [Fase 6](docs/architecture/phase6.md) e [Fase 7](docs/architecture/phase7.md).

## Execução local no Windows

Python 3.13, Node.js 22.14+, npm e PowerShell. Dependências instaladas somente no venv do projeto e no frontend; venv, caches e banco ativo ficam fora do OneDrive. Comandos a partir da pasta Chronos:

```powershell
$env:CHRONOS_RUNTIME_DIR = Join-Path $env:LOCALAPPDATA 'Chronos\1.0'
.\scripts\setup.ps1
.\scripts\create-admin.ps1
```

Setup instala as dependências travadas, preserva `.env` existente, gera configuração local segura quando ausente, aplica migrations e importa a demonstração. A senha do administrador é escolhida no terminal; não existe senha padrão. Para login: organização `horizonte`, usuário `admin`.

Em terminais separados, mantendo o mesmo `CHRONOS_RUNTIME_DIR`:

```powershell
.\scripts\start-backend.ps1
```

```powershell
.\scripts\start-frontend.ps1
```

Para processar os cálculos, em outro terminal:

```powershell
.\scripts\start-worker.ps1
```

Para consumir eventos e, opcionalmente, executar as agendas:

```powershell
.\scripts\start-automations.ps1 -Scheduler
```

Na **Central de automações**, configure o responsável e habilite apenas as rotinas desejadas. `-Once` processa um item; sem `-Scheduler`, o consumidor processa somente eventos e solicitações manuais. Nenhum serviço do Windows é criado. As sete rotinas começam desativadas; alertas e sugestões não aprovam regras ou propostas.

O n8n é opcional. [Configuração e workflows locais](automation/n8n/README.md) explicam Node 24 portátil, credenciais e comandos. O frontend continua usando seu Node 22; a integração não exige instalação global, Ollama ou API paga.

Em **Otimização de escalas**, escolha um cenário com demanda, informe os plantões e limites aplicáveis e envie para cálculo. Os registros sintéticos podem ser analisados em modo de hipótese, mas não são aprovados automaticamente. Revisões individuais de contrato, habilitação, jornada e demanda exigem fonte/evidência; regras utilizam versões revisadas. Uma aprovação exige outro responsável. O worker processa a fila somente enquanto estiver ativo.

Abra [interface local](http://127.0.0.1:5187), entre com organização `horizonte`, usuário `admin` e a senha escolhida. O perfil define as telas e ações disponíveis. [Swagger](http://127.0.0.1:8017/docs) e [prontidão do banco](http://127.0.0.1:8017/api/v1/health/ready) continuam disponíveis. Para testar clientes Bearer no Swagger, use `/api/v1/auth/login` e **Authorize**; a interface usa as rotas de sessão web com cookie/CSRF. Ctrl+C encerra os servidores próprios do Chronos.

O dashboard consulta `/api/v1/analytics/overview`, com dados calculados do banco e escopo do usuário. A fixture pública `/demo/summary` permanece somente para compatibilidade histórica e não alimenta as telas operacionais. Cobertura, custos projetados e conformidade aparecem como ainda não calculados/não avaliados.

## PostgreSQL e modo leve

PostgreSQL/psycopg é o alvo principal. Configure `CHRONOS_DATABASE_URL` e `CHRONOS_JWT_SECRET` no ambiente ou `.env`, conforme `.env.example`, e execute migrations/seed. A opção SQLite exige `CHRONOS_ALLOW_SQLITE=true`, não é permitida em produção e rejeita arquivo de banco dentro do projeto/OneDrive. Produção também exige `CHRONOS_COOKIE_SECURE=true`, HTTPS e frontend/API sob mesma origem. `.env` e senhas não são versionados.

Há `docker-compose.yml` com PostgreSQL 17, porta de loopback 5547 e volume próprio; exige Docker e `CHRONOS_POSTGRES_PASSWORD` definidos pelo usuário. Docker não foi instalado nesta máquina. Nesta sessão, PostgreSQL 17.11 portátil foi usado para testes reais sem criar serviço do Windows; detalhes e limites no relatório da Fase 2.

A execução observada utilizou este runtime já preparado:

```powershell
$env:CHRONOS_RUNTIME_DIR = 'C:\Users\leand\.codex\visualizations\2026\10\24\01a16f80-a854-7dd2-abbc-ed567dc8b313\chronos-runtime'
```

## Gerenciamento e verificações

```powershell
$pythonPath = Join-Path $env:CHRONOS_RUNTIME_DIR 'venv\Scripts\python.exe'
& $pythonPath .\backend\scripts\manage.py migrate
& $pythonPath .\backend\scripts\manage.py seed-demo
.\scripts\check.ps1
```

Seed repetida não duplica nem sobrescreve alterações manuais. Para restaurar explicitamente os dados de negócio fictícios:

```powershell
& $pythonPath .\backend\scripts\manage.py restore-demo --confirm 'Hospital Horizonte'
```

Restauração aceita somente o Hospital Horizonte marcado demo e ambiente development/test; mantém acessos, unidades e auditoria. Não existe endpoint público de restauração.

O check geral executa backend, testes de componentes e build frontend. Para PostgreSQL externo, configure `CHRONOS_TEST_POSTGRES_URL` para banco **exclusivo terminado em `_test`** e execute o check; a suite usa schemas aleatórios próprios. Sem configuração PostgreSQL, o check executa SQLite e informa um teste PostgreSQL skipped; isso não equivale a validar PostgreSQL. O runtime preparado nesta máquina permite `scripts\test-portable-postgres.ps1`, que inicia/testa/encerra o PostgreSQL portátil. Resultados atuais em [exportação cadastral de 27/10](docs/testing/people-export-2026-10-27-report.md); formulários em [homologação anterior](docs/testing/homologation-2026-10-27-report.md); preparação anterior em [relatório da Fase 10](docs/testing/phase10-report.md); validação do núcleo em [relatório da Fase 9](docs/testing/phase9-report.md); relatórios anteriores permanecem históricos.

Smoke HTTP isolado, com portas 8017/5187 livres:

```powershell
& $pythonPath .\backend\scripts\smoke_phase7.py --runtime $env:CHRONOS_RUNTIME_DIR
```

**O smoke n8n da Fase 7 está bloqueado pela auditoria da Fase 9.** As evidências antigas foram preservadas; não o execute até nova liberação. O smoke do núcleo atual é `backend/scripts/smoke_phase9.py --runtime CAMINHO_RUNTIME`.

A descrição histórica do smoke da Fase 7 exige o runtime n8n opcional preparado. Usa bancos/contas/credenciais sintéticos isolados, executa duas otimizações reais, os quatro workflows e o retorno autenticado à API, testa replay e sugestão de recálculo e encerra seus processos. Não modifica o banco principal. Os smokes históricos das Fases 3–6 continuam disponíveis para os respectivos fluxos HTTP/proxy.

## Analytics e exportações

Acesse **Analytics e exportações** no menu, selecione unidade, mês opcional e versão. Acrescente uma otimização e uma projeção da mesma versão, conforme suas permissões. CSV gera um ZIP de tabelas com manifest, consultas Power Query e medidas DAX. XLSX contém resumo com fórmulas e dados tipados. Atribuições individuais são opcionais e exigem leitura de pessoas. A extração é limitada a 20.000 registros e 8 MiB; não há truncamento silencioso.

A capacidade é simulada; cobertura é calculada no horizonte do solver; custos são projetados por 12 meses. Tentativas de automação são contadas pelo mês civil do cenário. O sistema não soma alternativas nem declara economia ou conformidade jurídica com base no relatório. O fallback explicativo funciona sem IA externa. Consulte [arquitetura da Fase 8](docs/architecture/phase8.md) e [importação Power BI](docs/integrations/power-bi.md).

## Documentação

- [Acesso genérico para apresentação](docs/portfolio/acesso-demonstracao.md): conta demonstrativa de consulta; o endereço público ainda não foi configurado.
- [Manual de instruções passo a passo](docs/manual-de-uso.md) e [PDF para leitura/impressão](output/pdf/Chronos-1.0-Manual-de-Uso.pdf), incluindo acesso, cadastros, cenários, otimização e operação local.
- [Prompt Mestre Chronos 1.0 consolidado](docs/requirements/PROMPT_MESTRE_CHRONOS_1.0.md) e [requisitos](docs/requirements/requirements.md).
- [Arquitetura inicial](docs/architecture/architecture.md), [backend](docs/architecture/phase2.md), [frontend e sessão](docs/architecture/phase3.md), [calendário e regras](docs/architecture/phase4.md), [cenários e financeiro](docs/architecture/phase5.md), [modelo relacional](docs/database/model.md) e [API](docs/api/api.md).
- [LaborRules](docs/legal-rules/labor-rules.md), [otimização](docs/architecture/optimization.md), [financeiro/processos/n8n](docs/business-process/processes.md).
- [Homologação atual: CSV cadastral](docs/testing/people-export-2026-10-27-report.md), [homologação dos formulários](docs/testing/homologation-2026-10-27-report.md), [relatório da Fase 10](docs/testing/phase10-report.md), [validação do núcleo na Fase 9](docs/testing/phase9-report.md), [relatório histórico da Fase 8](docs/testing/phase8-report.md), [relatório histórico da Fase 7](docs/testing/phase7-report.md), [relatório histórico da Fase 6](docs/testing/phase6-report.md), [relatório histórico da Fase 5](docs/testing/phase5-report.md), [relatório histórico da Fase 4](docs/testing/phase4-report.md), [relatório histórico da Fase 3](docs/testing/phase3-report.md), [execução e testes do backend](docs/testing/phase2.md), [relatório histórico da Fase 2](docs/testing/phase2-report.md) e [roadmap/próxima fase](docs/roadmap.md).
- [Relatório histórico da Fase 1](docs/testing/phase1-report.md), [changelog](CHANGELOG.md) e [metadados](release.json).

Os quantitativos são sintéticos e não estabelecem mínimos profissionais ou comprovação universal de cobertura. A aplicação apoia a revisão de regras, sem certificação jurídica. Automações e integrações externas de negócio permanecem desativadas. Esta entrega não é um release de produção.

## Atualização de dados sintéticos legados

A Fase 5 normaliza indisponibilidades para UTC na API e no importador, corrigindo perda de deslocamento no SQLite. Em banco de demonstração importado antes dessa correção, faça backup e execute `backend/scripts/repair_demo_times.py` com o Python do runtime. O comando só modifica registros do Hospital Horizonte que coincidam exatamente com a fixture legada; ignora divergências e recusa produção. Registros manuais não têm fuso inferido. Nesta máquina, 20 registros confirmados foram corrigidos, sem restaurar a fixture nem alterar salários/pessoas. O backup pré-migração 007 está no runtime externo.

## Segurança e recuperação da Fase 9

A API limita o corpo a 1 MiB e o recebimento a 10 segundos por padrão. Produção exige origens HTTPS explícitas, cookies Secure e banco/segredo válidos; docs/OpenAPI públicos ficam fechados. Esses controles não configuram proxy/TLS ou publicam a aplicação.

A migration 010_pattern_revision corrige a revisão de jornadas sem remover o controle de concorrência. Faça backup antes de migrar; o endpoint ready exige o head atual. A recuperação SQLite cria apenas um destino novo, com sessões/chaves revogadas e efeitos suspensos. Procedimentos e limites em [recuperação](docs/operations/recovery.md), [arquitetura](docs/architecture/phase9.md) e [achados](docs/security/phase9-findings.md).

O Vitest foi atualizado para 5.0.5, compatível com Node >=22.12 (esta máquina usa 22.14). A auditoria n8n permanece bloqueante, inclusive na candidata 2.45.4 auditada em 27/10, que não foi instalada (8 itens críticos e 81 altos). Não use o downgrade automático sugerido pelo npm. Não há liberação de produção ou publicação nesta fase.

## Entrega local da Fase 10

Comece pelo [índice de entrega](docs/release/README.md), [handover](docs/release/handover.md) e [manual](docs/user-guide.md). O [estudo de caso](docs/portfolio/case-study.md), [roteiro](docs/portfolio/demo-script.md) e [cobertura](docs/portfolio/coverage.md) distinguem evidências, hipóteses e itens pendentes. O microensaio não mede trabalho humano nem demonstra ganho real de produtividade/economia.

O pacote `releases/chronos-1.0-phase10-checkpoint.zip` contém fontes, fixture, documentação e build frontend, com manifest interno e recibo de hash externo. Não inclui banco ativo, contas, segredos ou runtimes. Para verificar: `python scripts/package_release.py verify releases/chronos-1.0-phase10-checkpoint.zip`. Gere outra cópia com o comando build descrito no handover, escolhendo um destino novo.

Screenshots continuam pendentes, com plano em docs/release/screenshots.json. O campo phase=10 identifica esta preparação documental; a API health continua indicando o núcleo validado na Fase 9. Nenhuma nova função de negócio ou migração foi acrescentada nesta etapa. `release_ready=false`, `published=false`.

## Homologação local de 27/10/2026

O detalhe do colaborador agora permite criar contratos, qualificações e competências conforme as permissões, mantendo revisão pendente e salários restritos por unidade. O formulário de indisponibilidade utiliza o fuso da unidade. Evidências e limites em [relatório](docs/testing/homologation-2026-10-27-report.md).

Novo pacote de revisão: `releases/chronos-1.0-homologacao-2026-10-27.zip`. Verifique com `python scripts/package_release.py verify releases/chronos-1.0-homologacao-2026-10-27.zip`. O arquivo anterior da Fase 10 permanece histórico. Esta rodada adiciona interface e testes, sem migration ou alteração do banco principal; produção e publicação continuam pendentes.

## Exportação cadastral — 27/10/2026

Na tela **Colaboradores**, exporte o CSV de todas as páginas dos filtros selecionados, dentro das unidades autorizadas. Campos básicos, sem salários ou evidências; limites de 20.000 linhas/8 MiB, proteção de fórmula, hash e auditoria. Detalhes em [relatório](docs/testing/people-export-2026-10-27-report.md) e [manual](docs/user-guide.md).

Pacote atual: `releases/chronos-1.0-exportacao-cadastral-2026-10-27.zip`. Verifique com `python scripts/package_release.py verify releases/chronos-1.0-exportacao-cadastral-2026-10-27.zip`. Os anteriores são históricos. Não há alteração do banco principal, migration ou publicação; os aceites pendentes permanecem registrados.
