# Chronos 1.0 — Material de entrega para revisão

Nome oficial: **Chronos — Gestão Inteligente de Jornadas e Escalas**. Cliente fictício: Hospital Horizonte. O pacote é local, sem publicação e com `release_ready=false`.

| Material | Uso |
|---|---|
| [Instalação e handover](handover.md) | Recriar a demonstração, configurar runtime e conferir o pacote |
| [Manual do usuário](../user-guide.md) | Entender telas, permissões, estados e limites |
| [Manual passo a passo](../manual-de-uso.md) e [PDF](../../output/pdf/Chronos-1.0-Manual-de-Uso.pdf) | Roteiro inicial e instruções dos módulos e da operação local |
| [Roteiro de demonstração](../portfolio/demo-script.md) | Apresentar as funções com dados fictícios e evidências reais |
| [Estudo de caso](../portfolio/case-study.md) | Problema proposto, decisões técnicas e resultados com limites |
| [Microensaio medido](../portfolio/benchmark.json) | Comparar política simulada/CP-SAT sem alegar ganho humano |
| [Cobertura funcional](../portfolio/coverage.md) | Verificar requisitos implementados, parciais e bloqueados |
| [Acesso de demonstração](../portfolio/acesso-demonstracao.md) | Credenciais genéricas, permissões e pendência de endereço público |
| [Estado e aceites pendentes](status.json) | Saber por que o release de produção não está liberado |
| [Plano de capturas](screenshots.json) | Registrar telas/temas e pendência de screenshot real |
| [Relatório da Fase 9](../testing/phase9-report.md) | Testes do núcleo, auditorias, recuperação e Excel |
| [Exportação cadastral de 27/10](../testing/people-export-2026-10-27-report.md) | CSV por filtros, permissões, limites e evidências desta rodada |
| [Homologação de 27/10](../testing/homologation-2026-10-27-report.md) | Formulários de vínculos, testes e nova auditoria n8n |
| [Relatório da Fase 10](../testing/phase10-report.md) | Preparação e verificação deste pacote |

O ZIP inclui `RELEASE-MANIFEST.json` com inventário e SHA-256 por arquivo. O recibo `.zip.receipt.json`, ao lado do ZIP, contém o hash do arquivo completo. Esse recibo fica fora do pacote para evitar circularidade. O manifest não transforma o pacote em release assinado ou aprovado.

Não há screenshots da aplicação nesta entrega. O bloqueio anterior de automação visual foi respeitado; nenhuma captura foi fabricada. Capturas e QA permanecem aceites pendentes, junto da remediação/revalidação n8n e do Power BI Desktop. O build frontend e os renders de planilhas não substituem essas verificações.

O banco de demonstração é **recriado pela fixture/migrations**. Contas, `.env`, segredos, dumps/backups, arquivos SQLite, caches, node_modules e venv não acompanham o ZIP. O núcleo pode ser executado localmente após instalar/configurar as dependências; o pacote não publica serviços nem altera outros projetos.
