# Chronos 1.0 — Instalação e entrega para revisão

Este é um **pacote local de revisão**. Não é instalador autônomo, serviço publicado ou release de produção. Inclui código, dependências fixadas, migrations, fixture fictícia, testes, documentação e build frontend quando indicado no manifest. Não inclui banco ativo, contas, senhas, venv, Node, node_modules ou caches.

## Requisitos e primeira execução no Windows

Use Python 3.13 e Node compatível com o frontend; a validação registrada utilizou Node 22.14 e npm 10.9.2. Vitest 5 requer Node >=22.12 nesta linha. Não é necessário instalar n8n para executar as funções centrais. PostgreSQL é o banco principal de referência; o perfil SQLite local é opt-in e mantém o arquivo fora do projeto/OneDrive.

Confira o SHA-256 externo do ZIP e execute a verificação antes de extrair/usar arquivos. O manifest interno verifica integridade dos membros; ele e o recibo não são assinatura digital de autoria. Compare o hash com a entrega recebida por canal confiável.

```powershell
Get-FileHash -LiteralPath '.\releases\chronos-1.0-phase10-checkpoint.zip' -Algorithm SHA256
python .\scripts\package_release.py verify '.\releases\chronos-1.0-phase10-checkpoint.zip'
```

Extraia o pacote numa pasta nova. Na raiz **Chronos-1.0**, escolha um runtime privado fora do OneDrive, por exemplo:

```powershell
$env:CHRONOS_RUNTIME_DIR = Join-Path $env:LOCALAPPDATA 'Chronos\1.0'
.\scripts\setup.ps1 -RuntimeDir $env:CHRONOS_RUNTIME_DIR
.\scripts\create-admin.ps1 -RuntimeDir $env:CHRONOS_RUNTIME_DIR
```

Setup instala dependências locais, gera `.env` apenas se não existir, aplica migrations e importa a fixture sem sobrescrever uma demonstração já importada. O operador escolhe a senha do administrador. O pacote não transporta o `.env` ou o administrador de outra máquina. Não execute setup sobre uma configuração existente sem conferir banco/runtime e fazer backup.

Em terminais separados na raiz do projeto:

```powershell
.\scripts\start-backend.ps1 -RuntimeDir $env:CHRONOS_RUNTIME_DIR
.\scripts\start-frontend.ps1 -RuntimeDir $env:CHRONOS_RUNTIME_DIR
.\scripts\start-worker.ps1 -RuntimeDir $env:CHRONOS_RUNTIME_DIR
```

Abra `http://127.0.0.1:5187`; organização `horizonte`, usuário/senha criados pelo operador. Backend usa loopback 8017. O worker consome otimizações; uma execução pode ficar queued enquanto ele estiver parado. Para automações locais, use outro terminal:

```powershell
.\scripts\start-automations.ps1 -RuntimeDir $env:CHRONOS_RUNTIME_DIR
```

O scheduler temporal só é ativado com `-Scheduler`; as definições ainda precisam ser habilitadas com responsável e parâmetros. Não habilite integrações externas para a apresentação. Setup/partida n8n permanecem bloqueados pelo estado de segurança.

## Conferências

`/api/v1/health/ready` deve indicar schema **010_pattern_revision**. A fixture inicial tem 350 colaboradores e 19 setores. Um ambiente de teste que cadastre pessoas extras terá outra contagem; isso não altera o total esperado do banco principal preservado.

Para testes, use o Python do runtime:

```powershell
$pythonPath = Join-Path $env:CHRONOS_RUNTIME_DIR 'venv\Scripts\python.exe'
& $pythonPath .\backend\scripts\generate_demo.py --check
& $pythonPath .\scripts\validate_phase1.py
& $pythonPath .\backend\scripts\run_tests.py -q
```

Sem PostgreSQL de teste configurado, SQLite não substitui sua validação. O perfil portátil já preparado nesta máquina pode ser exercitado por `scripts/test-portable-postgres.ps1`; noutra instalação, configure um banco exclusivo terminado em `_test` e os binários pg_dump/pg_restore conforme o [guia de recuperação](../operations/recovery.md). Os binários portáteis e suas credenciais não estão no ZIP.

Para testes de frontend/build, execute `npm test` e `npm run build` em `frontend`. Os resultados históricos da Fase 9 continuam identificados por data; este pacote não os apresenta como testes novos.

## Gerar e verificar outra cópia

```powershell
python .\scripts\package_release.py build --output 'C:\CAMINHO_PRIVADO\chronos-1.0-revisao-nova.zip' --include-build
python .\scripts\package_release.py verify 'C:\CAMINHO_PRIVADO\chronos-1.0-revisao-nova.zip'
```

O destino não pode existir. O builder usa uma seleção explícita de fontes, recusa links e segredos locais encontrados, exclui runtimes/dados ativos e cria inventário de hashes. Datas ZIP fixas e ordem estável tornam pacotes dos mesmos bytes reproduzíveis. O recibo externo contém SHA-256 do ZIP; fica fora dele para evitar autorreferência. Não modifique arquivos depois de gerar o pacote e ainda use o recibo antigo.

## Retomada e produção

Os próximos aceites estão em [status.json](status.json): n8n, navegador/capturas, Power BI Desktop, cobertura funcional pendente e revisão operacional final. Não altere `release_ready` ou remova bloqueios apenas para distribuir. Nenhuma publicação é realizada pelo empacotador.

O build frontend incluído não configura HTTPS, proxy, banco, certificados ou serviço estático de produção. A migração do ambiente operacional e a eventual publicação exigem revisão e autorização próprias. Backup/restauração nunca é substituído pela simples extração do ZIP sobre o banco existente.
