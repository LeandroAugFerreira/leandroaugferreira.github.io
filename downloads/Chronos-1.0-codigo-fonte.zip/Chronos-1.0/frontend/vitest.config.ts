import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  test: { environment: 'jsdom', setupFiles: ['./src/tests/setup.ts'], globals: false,
    pool: 'forks', maxWorkers: 1, fileParallelism: false },
})
