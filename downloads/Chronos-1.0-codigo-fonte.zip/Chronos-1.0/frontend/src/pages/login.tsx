import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { ArrowRight, Clock3, ShieldCheck } from 'lucide-react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../hooks/auth'
import { Field, Notice } from '../components/ui'

const schema = z.object({ organization: z.string().trim().min(1, 'Informe sua organização.'), username: z.string().trim().min(1, 'Informe seu usuário.'), password: z.string().min(1, 'Informe sua senha.') })
export function LoginPage() {
  const { user, login, message } = useAuth()
  const [error, setError] = useState('')
  const { register, handleSubmit, resetField, formState: { errors, isSubmitting } } = useForm<z.infer<typeof schema>>({ resolver: zodResolver(schema), defaultValues: { organization: 'horizonte', username: '', password: '' } })
  if (user) return <Navigate to="/" replace />
  return <div className="login-page"><section className="login-story"><a className="brand" href="/" aria-label="Chronos 1.0"><Clock3 /><span>chronos<small>GESTÃO INTELIGENTE DE JORNADAS E ESCALAS</small></span></a><div className="story-copy"><p className="eyebrow">PESSOAS. TEMPO. POSSIBILIDADES.</p><h1>Uma nova perspectiva<br />para sua operação.</h1><p>Conecte sua estrutura, organize equipes e prepare decisões com dados.</p><div className="clock-art" aria-hidden="true"><div /><i /><b /></div></div><div className="story-footer"><span>Chronos 1.0</span><span>Planejar com clareza.</span></div></section><main className="login-main"><div className="login-card"><span className="login-label"><ShieldCheck size={16} /> ACESSO À PLATAFORMA</span><h2>Bem-vindo ao Chronos</h2><p className="subtitle">Entre com as credenciais da sua organização.</p>{(error || message) && <Notice error>{error || message}</Notice>}<form onSubmit={handleSubmit(async values => { setError(''); try { await login(values.organization, values.username, values.password) } catch (err) { setError((err as Error).message); resetField('password') } })}>
      <Field label="Organização" error={errors.organization?.message}><input {...register('organization')} autoComplete="organization" aria-invalid={!!errors.organization} /></Field><Field label="Usuário" error={errors.username?.message}><input {...register('username')} autoComplete="username" aria-invalid={!!errors.username} /></Field><Field label="Senha" error={errors.password?.message}><input {...register('password')} type="password" autoComplete="current-password" aria-invalid={!!errors.password} /></Field><button className="button primary login-submit" disabled={isSubmitting}>{isSubmitting ? 'Entrando…' : 'Entrar na plataforma'}<ArrowRight size={18} /></button></form><div className="login-footnote"><span className="status-dot" />Ambiente de demonstração · dados fictícios</div></div><p className="login-copyright">Chronos 1.0 — Gestão Inteligente de Jornadas e Escalas</p></main></div>
}
