import { lazy, Suspense, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link, NavLink, Navigate, Outlet, Route, Routes, useLocation } from 'react-router-dom'
import { Building2, Clock3, FileClock, LayoutDashboard, Layers3, LogOut, Menu, Moon, Settings2, ShieldCheck, Sun, Users, X } from 'lucide-react'
import { useAuth } from './hooks/auth'
import { api } from './services/client'
import { globalPermission, permits, type Organization } from './types/domain'
import { Failure, Loading } from './components/ui'
import { LoginPage } from './pages/login'
import { EmployeesPage, EmployeeDetailPage } from './pages/employees'
import { CatalogsPage, StructurePage } from './pages/structure'
import { AuditPage, UsersPage } from './pages/administration'

const OverviewPage = lazy(() => import('./pages/overview').then(module => ({ default: module.OverviewPage })))
const CalendarPage = lazy(() => import('./pages/scheduling').then(module => ({ default: module.CalendarPage })))
const ScenariosPage = lazy(() => import('./pages/simulation').then(module => ({ default: module.ScenariosPage })))
const FinancialPage = lazy(() => import('./pages/simulation').then(module => ({ default: module.FinancialPage })))
const AutomationPage = lazy(() => import('./pages/automation').then(module => ({ default: module.AutomationPage })))
const AnalyticsPage = lazy(() => import('./pages/analytics').then(module => ({ default: module.AnalyticsPage })))
const OptimizationPage = lazy(() => import('./pages/optimization').then(module => ({ default: module.OptimizationPage })))
const RulesPage = lazy(() => import('./pages/scheduling').then(module => ({ default: module.RulesPage })))

function RequirePermission({ permission, global = false }: { permission: string; global?: boolean }) {
  const { user } = useAuth()
  const allowed = global ? globalPermission(user, permission) : permits(user, permission)
  return allowed ? <Outlet /> : <section className="panel forbidden"><ShieldCheck size={34} /><h1>Acesso restrito</h1><p>Seu perfil não possui permissão para esta área.</p><Link className="button secondary" to="/">Voltar à visão geral</Link></section>
}

function Layout() {
  const { user, logout } = useAuth()
  const location = useLocation()
  const [open, setOpen] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  const [leaving, setLeaving] = useState(false)
  const [theme, setTheme] = useState(() => { try { return localStorage.getItem('chronos-theme') === 'light' ? 'light' : 'dark' } catch { return 'dark' } })
  const organization = useQuery({ queryKey: ['organization'], queryFn: ({ signal }) => api.get<{ items: Organization[] }>('/organizations', signal) })
  const links = [
    { to: '/', label: 'Visão geral', icon: LayoutDashboard, permission: 'org:read' },
    { to: '/colaboradores', label: 'Colaboradores', icon: Users, permission: 'people:read' },
    { to: '/calendario', label: 'Calendário', icon: FileClock, permission: 'schedule:read' },
    { to: '/cenarios', label: 'Cenários', icon: Layers3, permission: 'scenario:read' },
    { to: '/otimizacao', label: 'Otimização de escalas', icon: Layers3, permission: 'optimization:read' },
    { to: '/automacoes', label: 'Central de automações', icon: Settings2, permission: 'automation:read' },
    { to: '/financeiro', label: 'Simulador financeiro', icon: LayoutDashboard, permission: 'finance:read' },
    { to: '/analytics', label: 'Analytics e exportações', icon: FileClock, permission: 'scenario:read' },
    { to: '/regras', label: 'Jornadas e regras', icon: Settings2, permission: 'rules:read' },
    { to: '/setores', label: 'Setores', icon: Layers3, permission: 'org:read' },
    { to: '/unidades', label: 'Unidades', icon: Building2, permission: 'org:read' },
    { to: '/catalogos', label: 'Catálogos', icon: Settings2, permission: 'catalog:read' },
    { to: '/acessos', label: 'Acessos', icon: ShieldCheck, permission: 'users:write', global: true },
    { to: '/auditoria', label: 'Auditoria', icon: FileClock, permission: 'audit:read', global: true },
  ]
  function toggleTheme() { const next = theme === 'dark' ? 'light' : 'dark'; setTheme(next); try { localStorage.setItem('chronos-theme', next) } catch { /* Preferência apenas em memória. */ } }
  const org = organization.data?.items[0]
  const title = links.find(link => link.to === location.pathname)?.label || 'Detalhe do colaborador'
  return <div className="app" data-theme={theme}><a className="skip-link" href="#conteudo">Ir para o conteúdo</a>{open && <button className="sidebar-scrim" aria-label="Fechar navegação" onClick={() => setOpen(false)} />}<aside className={'sidebar ' + (open ? 'is-open' : '')}><Link className="brand" to="/" onClick={() => setOpen(false)} aria-label="Chronos 1.0, início"><Clock3 /><span>chronos<small>GESTÃO DE JORNADAS E ESCALAS</small></span></Link><button className="mobile-close icon-button" onClick={() => setOpen(false)} aria-label="Fechar menu"><X size={20} /></button><div className="workspace-label">SUA ORGANIZAÇÃO</div><div className="workspace"><span>{org?.name.split(' ').slice(0, 2).map(word => word[0]).join('') || '…'}</span><div><b>{org?.name || 'Carregando organização…'}</b><small>{org?.is_demo ? 'Ambiente de demonstração' : 'Workspace corporativo'}</small></div></div><p className="nav-label">PLANEJAMENTO E GESTÃO</p><nav aria-label="Navegação principal">{links.filter(link => link.global ? globalPermission(user, link.permission) : permits(user, link.permission)).map(link => <NavLink key={link.to} to={link.to} end={link.to === '/'} onClick={() => setOpen(false)}><link.icon size={18} />{link.label}</NavLink>)}</nav><div className="sidebar-bottom"><div className="version-tag"><Clock3 size={15} />Chronos 1.0<span className="status-dot" /></div><p>Dados fictícios para demonstração.</p><div className="account"><span className="avatar">{user?.username.slice(0, 2).toUpperCase()}</span><div><b>{user?.username}</b><small>Conta autenticada</small></div><button className="icon-button" aria-label="Sair da plataforma" disabled={leaving} onClick={async () => { setLeaving(true); setError(null); try { await logout() } catch { setError(new Error('Não foi possível encerrar a sessão no servidor. Tente novamente.')) } finally { setLeaving(false) } }}><LogOut size={17} /></button></div></div></aside><div className="content"><header className="topbar"><div><button className="icon-button menu-toggle" aria-label="Abrir menu" aria-expanded={open} onClick={() => setOpen(!open)}><Menu size={21} /></button><span>Workspace <span className="header-divider">/</span> <b>{title}</b></span></div><div><span className="header-demo">Demonstração</span><button className="icon-button" aria-label={theme === 'dark' ? 'Ativar tema claro' : 'Ativar tema escuro'} onClick={toggleTheme}>{theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}</button></div></header><main id="conteudo" tabIndex={-1}>{error && <Failure error={error} />}{organization.isError && <Failure error={organization.error} retry={() => void organization.refetch()} />}<Suspense fallback={<Loading />}><Outlet /></Suspense><footer><span>Chronos 1.0 — Gestão Inteligente de Jornadas e Escalas</span><span>Pessoas e tempo, em equilíbrio.</span></footer></main></div></div>
}

export function App() {
  const { user, loading } = useAuth()
  if (loading) return <div className="initial-loading"><Clock3 size={35} /><Loading /></div>
  if (!user) return <Routes><Route path="/login" element={<LoginPage />} /><Route path="*" element={<Navigate to="/login" replace />} /></Routes>
  return <Routes><Route path="/login" element={<Navigate to="/" replace />} /><Route element={<Layout />}><Route element={<RequirePermission permission="org:read" />}><Route index element={<OverviewPage />} /><Route path="/setores" element={<StructurePage key="departments" kind="departments" />} /><Route path="/unidades" element={<StructurePage key="units" kind="units" />} /></Route><Route element={<RequirePermission permission="people:read" />}><Route path="/colaboradores" element={<EmployeesPage />} /><Route path="/colaboradores/:id" element={<EmployeeDetailPage />} /></Route><Route element={<RequirePermission permission="scenario:read" />}><Route path="/cenarios" element={<ScenariosPage />} /><Route path="/analytics" element={<AnalyticsPage />} /></Route><Route element={<RequirePermission permission="automation:read" />}><Route path="/automacoes" element={<AutomationPage />} /></Route><Route element={<RequirePermission permission="optimization:read" />}><Route path="/otimizacao" element={<OptimizationPage />} /></Route><Route element={<RequirePermission permission="finance:read" />}><Route path="/financeiro" element={<FinancialPage />} /></Route><Route element={<RequirePermission permission="schedule:read" />}><Route path="/calendario" element={<CalendarPage />} /></Route><Route element={<RequirePermission permission="rules:read" />}><Route path="/regras" element={<RulesPage />} /></Route><Route element={<RequirePermission permission="catalog:read" />}><Route path="/catalogos" element={<CatalogsPage />} /></Route><Route element={<RequirePermission permission="users:write" global />}><Route path="/acessos" element={<UsersPage />} /></Route><Route element={<RequirePermission permission="audit:read" global />}><Route path="/auditoria" element={<AuditPage />} /></Route><Route path="*" element={<section className="panel forbidden"><h1>Página não encontrada</h1><Link to="/" className="button secondary">Voltar ao início</Link></section>} /></Route></Routes>
}


