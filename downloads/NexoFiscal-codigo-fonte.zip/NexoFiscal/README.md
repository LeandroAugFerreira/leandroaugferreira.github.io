# NexoFiscal

**Emissão simulada de NFS-e para demonstração de portfólio • v0.1.0**

Do cadastro do cliente ao documento: aplicação React e FastAPI para prestadores de serviços de diferentes setores. A jornada principal é **cliente PF/PJ → serviço e valor → revisão → documento e histórico**. A emissão avulsa funciona sem contrato, cobrança ou pagamento.

**Todos os documentos são simulados, com marca-d’água e sem validade fiscal.** Não há transmissão a prefeitura ou autorização governamental. O envio de e-mail pode ser real quando configurado e confirmado por Administrador ou Financeiro. A distribuição inicia sem configuração SMTP; o perfil público não pode enviar mensagens.

## Apresentação

Conheça as telas, a demonstração narrada e o download em [NexoFiscal no portfólio](https://leandroaugferreira.github.io/nexofiscal.html).

- [Demonstração guiada](docs/portfolio-guiado.md)
- [Organização das telas](docs/organizacao-telas.md)
- [Escopo entregue e limites](docs/requisitos.md)
- [Arquitetura](docs/arquitetura.md) e [API](docs/api.md)

## O que está pronto

- Clientes PF/PJ, serviços e empresa emissora.
- Emissão individual avulsa ou vinculada a uma cobrança integralmente paga.
- Revisão no servidor, validações cadastrais e proteção contra emissão duplicada.
- PDF A4 com marca-d’água, HTML e XML próprio demonstrativo.
- Rejeição, reprocessamento e cancelamento simulados com histórico persistido.
- Envio manual SMTP com PDF, histórico de tentativas e preparação de mensagem `.eml`.
- Login, conta pública de portfólio, perfis, administração de usuários e Minha conta.
- Seis rotinas executáveis na API ou no n8n, com idempotência e resultados registrados. As rotinas preparam entregas e lembretes; não enviam e-mails automaticamente.
- Filtros, CSV, temas, layout móvel, cabeçalhos/abas/filtros fixos e listas de cinco itens por página.
- Financeiro de apoio: planos, contratos, cobranças e registros manuais de pagamentos.

## Executar uma cópia limpa no Windows

Requisitos: **Python 3.13, Node.js 22 e internet para instalar dependências**. n8n, Docker e Gmail são opcionais; não são necessários para explorar a emissão simulada.

1. Extraia `NexoFiscal-codigo-fonte.zip` e abra PowerShell na pasta `NexoFiscal`.
2. Prepare a demonstração:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\infrastructure\setup-local.ps1 -Portfolio
```

3. Execute **Iniciar NexoFiscal.cmd** e abra [http://127.0.0.1:5180](http://127.0.0.1:5180).
4. Escolha **Entrar no portfólio**. Em **Sobre e demonstração → Demonstração**, selecione um exemplo PF/PJ ou de rejeição.

O assistente cria `.env`, gera a senha dos perfis auxiliares, instala dependências, aplica migrações e provisiona dados fictícios. `-Portfolio` habilita a conta pública somente na cópia em que o comando foi executado. Sem esse parâmetro, ela permanece desabilitada por padrão. O seed repetido preserva dados existentes.

O iniciador mantém API/interface em segundo plano e reutiliza serviços ativos. Não é um executável independente: Python e Node são necessários. Após reiniciar o computador, execute o atalho novamente.

### Contas demonstrativas

| Perfil | E-mail | Senha inicial |
|---|---|---|
| Portfólio | `portfolio@nexofiscal.example.com` | `NexoFiscalDemo@2026` |
| Administrador | `admin@nexofiscal.example.com` | `Adm@2026` |

Essas credenciais são públicas e destinadas à demonstração com dados fictícios. A senha administrativa segue `DEMO_ADMIN_PASSWORD` no primeiro seed e pode ser alterada em **Minha conta → Segurança**. Financeiro, Recepção e Contabilidade usam a senha local gerada em `DEMO_PASSWORD`. Alterar o arquivo após o seed não altera senhas persistidas. Veja [contas e perfis](docs/contas-e-perfis.md).

### Serviços locais

| Serviço | Endereço |
|---|---|
| Interface | http://127.0.0.1:5180 |
| API/Swagger | http://127.0.0.1:8010/docs |
| Healthcheck | http://127.0.0.1:8010/api/health |
| n8n, se instalado/configurado | http://127.0.0.1:5678 |

O SQLite fica em `backend/fitnota.db`. A distribuição não contém banco do autor, senhas SMTP, tokens, logs, backups ou instalações locais do n8n.

Início manual em dois terminais, a partir da raiz:

```powershell
# Terminal 1
Set-Location backend
.\.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8010
```

```powershell
# Terminal 2
Set-Location frontend
npm.cmd run dev
```

## Gmail e n8n opcionais

Para uma conta própria do Gmail, execute `infrastructure/configurar-gmail.ps1 -Email seu-endereco@gmail.com`; a senha de app é informada em entrada oculta. O transporte aceita TLS na porta 465 ou STARTTLS na 587. Administrador e Financeiro podem confirmar o envio na nota; Portfólio pode baixar `.eml` com PDF. “Aceita pelo SMTP” informa a aceitação pelo servidor; confira o recebimento no destino. Veja [documentos e Gmail](docs/nexofiscal-email-documentos.md).

Sem n8n, as seis rotinas funcionam pela opção **API local**. Consulte [rotinas e integração](n8n/docs/README.md). A validação local de 17/10 confirmou seis workflows publicados e execuções idempotentes; o código distribuído não reutiliza tokens nem dados dessa instalação.

## Verificações

```powershell
Set-Location backend
.\.venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m alembic check
Set-Location ..\frontend
npm.cmd run build
```

A última suíte funcional passou com **60 testes**, além do build e verificações de interface. Os testes usam banco separado e cobrem permissões, CSRF, validação, idempotência, documentos, e-mail simulado, isolamento e paginação. Datas/resultados em [verificação](docs/verificacao.md); a instalação limpa e a apresentação final em [fechamento](docs/fechamento-portfolio.md).

## Limites e evolução

O escopo funcional do portfólio está concluído. Integração fiscal oficial, cálculo tributário oficial, lotes, gateways, recorrência financeira, multiempresa, envio automático, OAuth, Excel e instalador independente ficam para versões futuras.

O runtime validado usa SQLite no Windows. Docker Compose/PostgreSQL têm configuração e migrações, mas **ainda não foram homologados em execução**. Consulte [implantação](docs/implantacao.md) antes de evoluir para hospedagem ou dados reais. A página pública apresenta o projeto e seus downloads; não hospeda a API fiscal.

Autoria: **Leandro Augusto Ferreira**.
